package com.example.new_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
